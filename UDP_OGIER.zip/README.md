# UDP Echo client and server

## Introduction

This project implements two parts of a networked system: a server and a client communicating over UDP.

* the client sends each line that the user enters on the standard input to the server over UDP. Additionally, it prints to the standard output the data that it receives from the server.
* the server waits for UDP input, and sends back any data it receives to the sender. Additionally, it will provide logging information on the standard error stream.

We can summarize the data flow like this:
> (client stdin) --> client --[UDP]--> server --[UDP]--> client --> (client stdout)

The client and server do not check that the UDP packets have been actually received on the other end ; the user should not expect reliability from the transmission.

## Compilation

A Makefile is provided. A call to `make` will build the two executables (`client` and `server`).

Debug builds can be obtained by building the executables directly in the source directory like so:
``` console
$ cd src_client
$ make BUILD=debug
```
The resulting file will be called `client.debug`.

## Usage

### Client

```
client <address> <port>
```

The client will prompt the user for input: each line of text the user inputs on stdin will be sent to the server at `<address>` on `<port>` over UDP. If the server at `<address>` sends back data, it will be printed on the standard output.

### Server
```
server <port>
```

The server will wait for UDP data on the port `<port>`. When data arrive from a sender over UDP, it will send back the data to the sender over UDP.




